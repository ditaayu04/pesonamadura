<?php
        include 'koneksi.php';
        // melakukan koneksi ke database
        $conn = mysqli_connect("localhost", "root", "", "webwisata");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Pesona Madura</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <!--tika-->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="https://code.highcharts.com/modules/drilldown.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>
    <!-- <link rel="stylesheet" href="/drilldown.css"/> -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
    <!---->

    <style>
    table {
        border-collapse: collapse;
        max-width: 900px; /* Atur lebar maksimum tabel sesuai kebutuhan */
        width: 100%;
        margin-left: auto;
        margin-right: auto;
    }

    th, td {
        border: 1px solid black;
        padding: 3px;
    }

    th {
        background-color: #f2f2f2;
    }
    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-info sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <!-- <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div> -->
                <div class="sidebar-brand-text mx-3">PESONA MADURA</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Chart Menu
            </div>

            <li class="nav-item">
                <a class="nav-link" href="chart_pengunjung.php">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Chart Pengunjung</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="chart_pendapatan.php">
                    <i class="fa fa-balance-scale"></i>
                    <span>Chart Pendapatan</span>
                </a>
            </li>


            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Edit Wisata
            </div>

            <li class="nav-item">
                <a class="nav-link" href="admin_bangkalan.php">
                    <span>Bangkalan</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="admin_sumenep.php">
                    <span>Sumenep</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="admin_pamekasan.php">
                    <span>Pamekasan</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="admin_sampang.php">
                    <span>Sampang</span>
                </a>
            </li>

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <div class="input-group" style="margin-left: 10px; color: #000000; font-weight: 500; font-size: 15pt">
                    <?php
                    include 'koneksi.php';
                    // melakukan koneksi ke database
                    $conn = mysqli_connect("localhost", "root", "", "webwisata");
                    $login = mysqli_query($conn, "SELECT * from admin");
                    ?>
                    <?php foreach ($login as $data): ?>
                    <h3>Selamat Datang, <b><?= $data['username']?></b></h3>
                    <?php endforeach; ?>
                    </div>
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-info" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Begin Page Content -->
                    <div class="container-fluid">
                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Pengunjung Keseluruhan</h1>
                        </div>

                        <!-- Content Row -->
                        <div class="row">
                            <!-- Awal Jumlah Pengunjung -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card border-left-primary shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                    Total Jumlah Pengunjung</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                    <?php  
                                                    $host       = "localhost";
                                                    $user       = "root";
                                                    $password   = "";
                                                    $database   = "webwisata";
                                                    $mysqli     = mysqli_connect($host, $user, $password, $database);

                                                    $sql = "SELECT COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_bangkalan
                                                    UNION ALL
                                                    SELECT COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_sumenep
                                                    UNION ALL
                                                    SELECT COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_pamekasan
                                                    UNION ALL
                                                    SELECT COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_sampang";

                                                    $query = mysqli_query($mysqli, $sql);
                                                    $total_pengunjung = 0;

                                                    while ($row = mysqli_fetch_array($query)) {
                                                        $total_pengunjung += $row['jumlah_pengunjung'];
                                                    }

                                                    echo number_format($total_pengunjung, 0, ",", ".");
                                                    ?>  
                                                    </div>
                                            </div>
                                            <div class="col-auto">
                                            <i class="fa fa-user fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Akhir Jumlah Pengunjung -->
                        </div>

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Pengunjung Tiap Kota</h1>
                        </div>

                        <!-- Content Row -->
                        <div class="row">
                        <!-- Bar Chart -->
                        <div class="col-xl-8 col-lg-7">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Jumlah Pengunjung Tiap Kota</h6>
                                    </div>
                                    <div class="card-body">
                                        <?php
                                        $host = "localhost";
                                        $user = "root";
                                        $password = "";
                                        $database = "webwisata";
                                        $mysqli = mysqli_connect($host, $user, $password, $database);

                                        // Mengambil data dari database
                                        $sql = "SELECT 'Bangkalan' AS wilayah, COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_bangkalan
                                                UNION ALL
                                                SELECT 'Sumenep' AS wilayah, COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_sumenep
                                                UNION ALL
                                                SELECT 'Pamekasan' AS wilayah, COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_pamekasan
                                                UNION ALL
                                                SELECT 'Sampang' AS wilayah, COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_sampang";
                                        $query = mysqli_query($mysqli, $sql);
                                        $total_pengunjung = 0;
                                        $data = array();

                                        while ($row = mysqli_fetch_assoc($query)) {
                                            $total_pengunjung += $row['jumlah_pengunjung'];
                                            $data[] = array(
                                                'name' => $row['wilayah'],
                                                'y' => (int) $row['jumlah_pengunjung']
                                            );
                                        }
                                        ?>
                                        <div class="highcharts">
                                            <div id="container1"></div>
                                            <script src="https://code.highcharts.com/highcharts.js"></script>
                                            <script>
                                                // Menginisialisasi grafik Highcharts
                                                Highcharts.chart('container1', {
                                                    chart: {
                                                        type: 'column' // Menggunakan tipe grafik column untuk membuat bar vertikal
                                                    },
                                                    title: {
                                                        text: 'Jumlah Pengunjung per Wilayah'
                                                    },
                                                    xAxis: {
                                                        type: 'category',
                                                        title: {
                                                            text: 'Wilayah'
                                                        }
                                                    },
                                                    yAxis: {
                                                        title: {
                                                            text: 'Jumlah Pengunjung'
                                                        }
                                                    },
                                                    legend: {
                                                        enabled: false
                                                    },
                                                    series: [{
                                                        name: 'Total Pengunjung',
                                                        data: <?php echo json_encode($data); ?>,
                                                        dataLabels: {
                                                            enabled: true,
                                                            format: '{point.y}'
                                                        }
                                                    }]
                                                });
                                            </script>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        
                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Pengunjung Tiap Destinasi di Bangkalan</h1>
                        </div>

                        <!-- Bar Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Jumlah Pengunjung Tiap Destinasi di Bangkalan</h6>
                                </div>
                                <div class="card-body">
                                    <?php
                                    $host = "localhost";
                                    $user = "root";
                                    $password = "";
                                    $database = "webwisata";
                                    $mysqli = mysqli_connect($host, $user, $password, $database);

                                    // Mengambil data dari database
                                    $sql = "SELECT destinasi, COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_bangkalan GROUP BY destinasi";
                                    $query = mysqli_query($mysqli, $sql);
                                    $total_pengunjung = 0;
                                    $data = array();

                                    while ($row = mysqli_fetch_assoc($query)) {
                                        $total_pengunjung += $row['jumlah_pengunjung'];
                                        $data[] = array(
                                            'name' => $row['destinasi'],
                                            'y' => (int) $row['jumlah_pengunjung']
                                        );
                                    }
                                    ?>
                                    <div class="highcharts">
                                        <div id="container2"></div>
                                        <script src="https://code.highcharts.com/highcharts.js"></script>
                                        <script>
                                            // Menginisialisasi grafik Highcharts
                                            Highcharts.chart('container2', {
                                                chart: {
                                                    type: 'column' // Menggunakan tipe grafik column untuk membuat bar vertikal
                                                },
                                                title: {
                                                    text: 'Jumlah Pengunjung Tiap Destinasi di Bangkalan'
                                                },
                                                xAxis: {
                                                    type: 'category',
                                                    title: {
                                                        text: 'Destinasi'
                                                    }
                                                },
                                                yAxis: {
                                                    title: {
                                                        text: 'Jumlah Pengunjung'
                                                    }
                                                },
                                                legend: {
                                                    enabled: false
                                                },
                                                series: [{
                                                    name: 'Total Pengunjung',
                                                    data: <?php echo json_encode($data); ?>,
                                                    dataLabels: {
                                                        enabled: true,
                                                        format: '{point.y}'
                                                    }
                                                }]
                                            });
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Pengunjung Tiap Destinasi di Sumenep</h1>
                        </div>

                        <!-- Bar Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Jumlah Pengunjung Tiap Destinasi di Sumenep</h6>
                                </div>
                                <div class="card-body">
                                    <?php
                                    $host = "localhost";
                                    $user = "root";
                                    $password = "";
                                    $database = "webwisata";
                                    $mysqli = mysqli_connect($host, $user, $password, $database);

                                    // Mengambil data dari database
                                    $sql = "SELECT destinasi, COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_sumenep GROUP BY destinasi";
                                    $query = mysqli_query($mysqli, $sql);
                                    $total_pengunjung = 0;
                                    $data = array();

                                    while ($row = mysqli_fetch_assoc($query)) {
                                        $total_pengunjung += $row['jumlah_pengunjung'];
                                        $data[] = array(
                                            'name' => $row['destinasi'],
                                            'y' => (int) $row['jumlah_pengunjung']
                                        );
                                    }
                                    ?>
                                    <div class="highcharts">
                                        <div id="container3"></div>
                                        <script src="https://code.highcharts.com/highcharts.js"></script>
                                        <script>
                                            // Menginisialisasi grafik Highcharts
                                            Highcharts.chart('container3', {
                                                chart: {
                                                    type: 'column' // Menggunakan tipe grafik column untuk membuat bar vertikal
                                                },
                                                title: {
                                                    text: 'Jumlah Pengunjung Tiap Destinasi di Sumenep'
                                                },
                                                xAxis: {
                                                    type: 'category',
                                                    title: {
                                                        text: 'Destinasi'
                                                    }
                                                },
                                                yAxis: {
                                                    title: {
                                                        text: 'Jumlah Pengunjung'
                                                    }
                                                },
                                                legend: {
                                                    enabled: false
                                                },
                                                series: [{
                                                    name: 'Total Pengunjung',
                                                    data: <?php echo json_encode($data); ?>,
                                                    dataLabels: {
                                                        enabled: true,
                                                        format: '{point.y}'
                                                    }
                                                }]
                                            });
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Pengunjung Tiap Destinasi di Pamekasan</h1>
                        </div>

                        <!-- Bar Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Jumlah Pengunjung Tiap Destinasi di Pamekasan</h6>
                                </div>
                                <div class="card-body">
                                    <?php
                                    $host = "localhost";
                                    $user = "root";
                                    $password = "";
                                    $database = "webwisata";
                                    $mysqli = mysqli_connect($host, $user, $password, $database);

                                    // Mengambil data dari database
                                    $sql = "SELECT destinasi, COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_pamekasan GROUP BY destinasi";
                                    $query = mysqli_query($mysqli, $sql);
                                    $total_pengunjung = 0;
                                    $data = array();

                                    while ($row = mysqli_fetch_assoc($query)) {
                                        $total_pengunjung += $row['jumlah_pengunjung'];
                                        $data[] = array(
                                            'name' => $row['destinasi'],
                                            'y' => (int) $row['jumlah_pengunjung']
                                        );
                                    }
                                    ?>
                                    <div class="highcharts">
                                        <div id="container4"></div>
                                        <script src="https://code.highcharts.com/highcharts.js"></script>
                                        <script>
                                            // Menginisialisasi grafik Highcharts
                                            Highcharts.chart('container4', {
                                                chart: {
                                                    type: 'column' // Menggunakan tipe grafik column untuk membuat bar vertikal
                                                },
                                                title: {
                                                    text: 'Jumlah Pengunjung Tiap Destinasi di Pamekasan'
                                                },
                                                xAxis: {
                                                    type: 'category',
                                                    title: {
                                                        text: 'Destinasi'
                                                    }
                                                },
                                                yAxis: {
                                                    title: {
                                                        text: 'Jumlah Pengunjung'
                                                    }
                                                },
                                                legend: {
                                                    enabled: false
                                                },
                                                series: [{
                                                    name: 'Total Pengunjung',
                                                    data: <?php echo json_encode($data); ?>,
                                                    dataLabels: {
                                                        enabled: true,
                                                        format: '{point.y}'
                                                    }
                                                }]
                                            });
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Pengunjung Tiap Destinasi di Sampang</h1>
                        </div>

                        <!-- Bar Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Jumlah Pengunjung Tiap Destinasi di Sampang</h6>
                                </div>
                                <div class="card-body">
                                    <?php
                                    $host = "localhost";
                                    $user = "root";
                                    $password = "";
                                    $database = "webwisata";
                                    $mysqli = mysqli_connect($host, $user, $password, $database);

                                    // Mengambil data dari database
                                    $sql = "SELECT destinasi, COUNT(DISTINCT id) AS jumlah_pengunjung FROM pemesanan_sampang GROUP BY destinasi";
                                    $query = mysqli_query($mysqli, $sql);
                                    $total_pengunjung = 0;
                                    $data = array();

                                    while ($row = mysqli_fetch_assoc($query)) {
                                        $total_pengunjung += $row['jumlah_pengunjung'];
                                        $data[] = array(
                                            'name' => $row['destinasi'],
                                            'y' => (int) $row['jumlah_pengunjung']
                                        );
                                    }
                                    ?>
                                    <div class="highcharts">
                                        <div id="container5"></div>
                                        <script src="https://code.highcharts.com/highcharts.js"></script>
                                        <script>
                                            // Menginisialisasi grafik Highcharts
                                            Highcharts.chart('container5', {
                                                chart: {
                                                    type: 'column' // Menggunakan tipe grafik column untuk membuat bar vertikal
                                                },
                                                title: {
                                                    text: 'Jumlah Pengunjung Tiap Destinasi di Sampang'
                                                },
                                                xAxis: {
                                                    type: 'category',
                                                    title: {
                                                        text: 'Destinasi'
                                                    }
                                                },
                                                yAxis: {
                                                    title: {
                                                        text: 'Jumlah Pengunjung'
                                                    }
                                                },
                                                legend: {
                                                    enabled: false
                                                },
                                                series: [{
                                                    name: 'Total Pengunjung',
                                                    data: <?php echo json_encode($data); ?>,
                                                    dataLabels: {
                                                        enabled: true,
                                                        format: '{point.y}'
                                                    }
                                                }]
                                            });
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- /.container-fluid -->

                </div>
                <!-- End of Main Content -->

                <!-- Footer -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright text-center my-auto">
                            <span>Copyright &copy; Pesona Madura 2023</span>
                        </div>
                    </div>
                </footer>
                <!-- End of Footer -->

            </div>
            <!-- End of Content Wrapper -->
 <!-- Logout Modal-->
 <button class="btn btn-info" onclick="logout()">Logout</button>

<script>
    function logout() {
        // Logika logout di sini
        // Anda dapat menambahkan kode untuk menjalankan tindakan logout yang diinginkan
        // Misalnya, menghapus sesi, mengirim permintaan ke server untuk logout, dll.

        // Mengarahkan pengguna ke halaman login
        window.location.href = "login_admin.php";
    }
</script>
        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>
        <!-- End Scroll to Top Button-->

          <!-- Logout Modal-->
   
        <!-- Bootstrap core JavaScript-->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="js/sb-admin-2.min.js"></script>

        <!-- Page level plugins -->
        <script src="js/demo/chart-bar-demo2.js"></script>
    </body>
</html>

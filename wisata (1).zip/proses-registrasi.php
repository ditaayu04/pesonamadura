<?php
include 'koneksi.php';

// melakukan koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "webwisata");

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Cek apakah email sudah terdaftar
    $checkQuery = mysqli_query($conn, "SELECT * FROM login WHERE email = '$email'");
    if (mysqli_num_rows($checkQuery) > 0) {
        echo "<script>alert('Email sudah terdaftar. Silakan gunakan email lain.'); window.location.href='registrasi.php' </script>";
    } else {
        // Menyimpan ke database
        $sql = mysqli_query($conn, "INSERT INTO login (email, password) VALUES ('$email', '$password')");

        if ($sql) {
            // pesan jika data tersimpan
            echo "<script>alert('Pembuatan Akun Berhasil!'); window.location.href='index.php'</script>";
        } else {
            // pesan jika data gagal disimpan
            echo "<script>alert('Akun Gagal Dibuat!'); window.location.href='registrasi.php'</script>";
        }
    }
}
?>

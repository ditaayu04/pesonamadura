<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'webwisata';

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die('Koneksi ke database gagal: ' . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Bangkalan</title>
    
    <!-- Favicon -->
    <link href="logo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Montserrat:500,700&display=swap&subset=latin-ext" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600&display=swap&subset=latin-ext" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-md navbar-dark bg-dark navbar-custom fixed-top">

        <!-- Image Logo -->
        <a class="navbar-brand logo-image" href="beranda.php">
            <img src="logo.png" alt="logo" width="30%">
        </a>
        
        <!-- Mobile Menu Toggle Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-awesome fas fa-bars"></span>
            <span class="navbar-toggler-awesome fas fa-times"></span>
        </button>
        <!-- end of mobile menu toggle button -->

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="beranda.php">HOME <span class="sr-only">(current)</span></a>
                </li>
            
                <!-- Dropdown Menu -->          
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">DESTINASI</a>
                    <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="bangkalan.php" class="dropdown-item">Bangkalan</a>
                                <a href="sampang.php" class="dropdown-item">Sampang</a>
                                <a href="pamekasan.php" class="dropdown-item">Pamekasan</a>
                                <a href="sumenep.php" class="dropdown-item">Sumenep</a>
                    </div>
                </li>
                <!-- end of dropdown menu -->

                 <!-- Dropdown Menu -->          
                 <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">BOOKING</a>
                    <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="pemesanan_bangkalan.php" class="dropdown-item">Bangkalan</a>
                                <a href="pemesanan_sampang.php" class="dropdown-item">Sampang</a>
                                <a href="pemesanan_pamekasan.php" class="dropdown-item">Pamekasan</a>
                                <a href="pemesanan_sumenep.php" class="dropdown-item">Sumenep</a>
                    </div>
                </li>
                <!-- end of dropdown menu -->

                 <!-- Dropdown Menu -->          
                 <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">AKUN</a>
                    <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="registrasi.php" class="dropdown-item">REGISTRASI</a>
                                <a href="index.php" class="dropdown-item">LOGIN</a>
                                <a href="login_admin.php" class="dropdown-item">ADMIN</a>
                    </div>
                </li>
                <!-- end of dropdown menu -->
         </nav> 
    <!-- end of navbar -->


    <br><br>

    <!-- Packages Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <div class="text-center mb-3 pb-3">
                <h6 class="text-info text-uppercase" style="letter-spacing: 5px;">Destinasi Wisata</h6>
                <br>
                <h1>Bangkalan</h1>
            </div>
            <br><br>
            <div class="row">
                <!-- Bukit Jaddih Start -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                        </ol>

                        <!-- Slides -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                            <img class="d-block w-100" src="bukit jaddih.png" alt="Slide 1">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="bukit jaddih-1.png" alt="Slide 2">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="bukit jaddih-2.png" alt="Slide 3">
                            </div>
                        </div>

                        <!-- Controls -->
                        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                        </div>

                        <div class="p-4">
                            <div style="display: grid; grid-template-rows: auto auto;">
                            <!-- Lokasi Start -->
                                <small class="m-0">
                                    <i class="fa fa-map-marker-alt text-info"></i>
                                    <?php
                                    $query = "SELECT lokasi FROM bangkalan WHERE id = 1";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $lokasi = $row['lokasi'];
                                    } else {
                                        $lokasi = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $lokasi; ?></span>
                                </small>
                            <!-- Lokasi End -->

                                <br>
                            <!-- Jam Start -->
                                <small class="m-0">
                                    <i class="fa fa-calendar-alt text-info"></i>
                                    <?php
                                    $query = "SELECT jam_buka, jam_tutup FROM bangkalan WHERE id = 1";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $jam_buka = $row['jam_buka'];
                                        $jam_tutup = $row['jam_tutup'];
                                    } else {
                                        $jam_buka = 'Data tidak ditemukan';
                                        $jam_tutup = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $jam_buka; ?></span> - <span><?php echo $jam_tutup; ?></span> WIB
                                </small>
                            <!-- Jam End -->
                            </div> 
                            <br>

                            <!-- Nama Wisata Start -->
                            <?php
                            $query = "SELECT nama_wisata FROM bangkalan WHERE id = 1";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $nama_wisata = $row['nama_wisata'];
                            } else {
                                $nama_wisata = 'Data tidak ditemukan';
                            }
                            ?>
                            <h4><?php echo $nama_wisata; ?></h4>
                            <!-- Nama Wisata End -->

                            <!-- Deskripsi Start -->
                            <?php
                            $query = "SELECT deskripsi FROM bangkalan WHERE id = 1";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $deskripsi = $row['deskripsi'];
                            } else {
                                $deskripsi = 'Data tidak ditemukan';
                            }
                            ?>
                            <p><?php echo $deskripsi; ?><p>
                            <!-- Deskripsi End -->

                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">

                                    <!-- Harga Start -->
                                    <div class="d-flex align-items-center">
                                        <h6 class="m-0 mr-4">
                                            <i class="fa fa-star text-info mr-2"></i>
                                            <?php
                                            $query = "SELECT harga FROM bangkalan WHERE id = 1";
                                            $result = $conn->query($query);

                                            if ($result->num_rows > 0) {
                                                $row = $result->fetch_assoc();
                                                $harga = $row['harga'];
                                            } else {
                                                $harga = 'Data tidak ditemukan';
                                            }
                                            ?>
                                            Rp. <?php echo $harga; ?>
                                        </h6>
                                        <!-- Harga End -->
                                        <a href="pemesanan_bangkalan.php" class="btn btn-info btn-sm py-2 px-4 ml-2">Pesan Sekarang</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Bukit Jaddih End -->

                <!-- Bukit Arosbaya Start -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                        </ol>

                        <!-- Slides -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                            <img class="d-block w-100" src="bukit arosbaya.png" alt="Slide 1">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="bukit arosbaya-2.png" alt="Slide 2">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="bukit arosbaya-3.png" alt="Slide 3">
                            </div>
                        </div>

                        <!-- Controls -->
                        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                        </div>

                        <div class="p-4">
                            <div style="display: grid; grid-template-rows: auto auto;">
                            <!-- Lokasi Start -->
                                <small class="m-0">
                                    <i class="fa fa-map-marker-alt text-info"></i>
                                    <?php
                                    $query = "SELECT lokasi FROM bangkalan WHERE id = 2";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $lokasi = $row['lokasi'];
                                    } else {
                                        $lokasi = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $lokasi; ?></span>
                                </small>
                            <!-- Lokasi End -->

                                <br>
                            <!-- Jam Start -->
                                <small class="m-0">
                                    <i class="fa fa-calendar-alt text-info"></i>
                                    <?php
                                    $query = "SELECT jam_buka, jam_tutup FROM bangkalan WHERE id = 2";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $jam_buka = $row['jam_buka'];
                                        $jam_tutup = $row['jam_tutup'];
                                    } else {
                                        $jam_buka = 'Data tidak ditemukan';
                                        $jam_tutup = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $jam_buka; ?></span> - <span><?php echo $jam_tutup; ?></span> WIB
                                </small>
                            <!-- Jam End -->
                            </div> 
                            <br>

                            <!-- Nama Wisata Start -->
                            <?php
                            $query = "SELECT nama_wisata FROM bangkalan WHERE id = 2";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $nama_wisata = $row['nama_wisata'];
                            } else {
                                $nama_wisata = 'Data tidak ditemukan';
                            }
                            ?>
                            <h4><?php echo $nama_wisata; ?></h4>
                            <!-- Nama Wisata End -->

                            <!-- Deskripsi Start -->
                            <?php
                            $query = "SELECT deskripsi FROM bangkalan WHERE id = 2";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $deskripsi = $row['deskripsi'];
                            } else {
                                $deskripsi = 'Data tidak ditemukan';
                            }
                            ?>
                            <p><?php echo $deskripsi; ?><p>
                            <!-- Deskripsi End -->

                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">

                                    <!-- Harga Start -->
                                    <div class="d-flex align-items-center">
                                        <h6 class="m-0 mr-4">
                                            <i class="fa fa-star text-info mr-2"></i>
                                            <?php
                                            $query = "SELECT harga FROM bangkalan WHERE id = 2";
                                            $result = $conn->query($query);

                                            if ($result->num_rows > 0) {
                                                $row = $result->fetch_assoc();
                                                $harga = $row['harga'];
                                            } else {
                                                $harga = 'Data tidak ditemukan';
                                            }
                                            ?>
                                            Rp. <?php echo $harga; ?>
                                        </h6>
                                        <!-- Harga End -->
                                        <a href="pemesanan_bangkalan.php" class="btn btn-info btn-sm py-2 px-4 ml-2">Pesan Sekarang</a>
                                        </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Bukit Arosbaya End -->

                <!-- Pantai Gebang Start -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                        </ol>

                        <!-- Slides -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                            <img class="d-block w-100" src="pantai gebang.png" alt="Slide 1">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="pantai gebang-2.png" alt="Slide 2">
                            </div>
                        </div>

                        <!-- Controls -->
                        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                        </div>

                        <div class="p-4">
                            <div style="display: grid; grid-template-rows: auto auto;">
                            <!-- Lokasi Start -->
                                <small class="m-0">
                                    <i class="fa fa-map-marker-alt text-info"></i>
                                    <?php
                                    $query = "SELECT lokasi FROM bangkalan WHERE id = 3";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $lokasi = $row['lokasi'];
                                    } else {
                                        $lokasi = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $lokasi; ?></span>
                                </small>
                            <!-- Lokasi End -->

                                <br>
                            <!-- Jam Start -->
                                <small class="m-0">
                                    <i class="fa fa-calendar-alt text-info"></i>
                                    <?php
                                    $query = "SELECT jam_buka, jam_tutup FROM bangkalan WHERE id = 3";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $jam_buka = $row['jam_buka'];
                                        $jam_tutup = $row['jam_tutup'];
                                    } else {
                                        $jam_buka = 'Data tidak ditemukan';
                                        $jam_tutup = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $jam_buka; ?></span> - <span><?php echo $jam_tutup; ?></span> WIB
                                </small>
                            <!-- Jam End -->
                            </div> 
                            <br>

                            <!-- Nama Wisata Start -->
                            <?php
                            $query = "SELECT nama_wisata FROM bangkalan WHERE id = 3";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $nama_wisata = $row['nama_wisata'];
                            } else {
                                $nama_wisata = 'Data tidak ditemukan';
                            }
                            ?>
                            <h4><?php echo $nama_wisata; ?></h4>
                            <!-- Nama Wisata End -->

                            <!-- Deskripsi Start -->
                            <?php
                            $query = "SELECT deskripsi FROM bangkalan WHERE id = 3";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $deskripsi = $row['deskripsi'];
                            } else {
                                $deskripsi = 'Data tidak ditemukan';
                            }
                            ?>
                            <p><?php echo $deskripsi; ?><p>
                            <!-- Deskripsi End -->

                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">

                                    <!-- Harga Start -->
                                    <div class="d-flex align-items-center">
                                        <h6 class="m-0 mr-4">
                                            <i class="fa fa-star text-info mr-2"></i>
                                            <?php
                                            $query = "SELECT harga FROM bangkalan WHERE id = 3";
                                            $result = $conn->query($query);

                                            if ($result->num_rows > 0) {
                                                $row = $result->fetch_assoc();
                                                $harga = $row['harga'];
                                            } else {
                                                $harga = 'Data tidak ditemukan';
                                            }
                                            ?>
                                            Rp. <?php echo $harga; ?>
                                        </h6>
                                        <!-- Harga End -->
                                        <a href="pemesanan_bangkalan.php" class="btn btn-info btn-sm py-2 px-4 ml-2">Pesan Sekarang</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Pantai Gebang End -->

                <!-- Pantai Siring Kemuning Start -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                        </ol>

                        <!-- Slides -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                            <img class="d-block w-100" src="pantai siring kemuning.png" alt="Slide 1">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="pantai siring kemuning-2.png" alt="Slide 2">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="pantai siring kemuning-3.png" alt="Slide 3">
                            </div>
                        </div>

                        <!-- Controls -->
                        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                        </div>

                        <div class="p-4">
                            <div style="display: grid; grid-template-rows: auto auto;">
                            <!-- Lokasi Start -->
                                <small class="m-0">
                                    <i class="fa fa-map-marker-alt text-info"></i>
                                    <?php
                                    $query = "SELECT lokasi FROM bangkalan WHERE id = 4";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $lokasi = $row['lokasi'];
                                    } else {
                                        $lokasi = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $lokasi; ?></span>
                                </small>
                            <!-- Lokasi End -->

                                <br>
                            <!-- Jam Start -->
                                <small class="m-0">
                                    <i class="fa fa-calendar-alt text-info"></i>
                                    <?php
                                    $query = "SELECT jam_buka, jam_tutup FROM bangkalan WHERE id = 4";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $jam_buka = $row['jam_buka'];
                                        $jam_tutup = $row['jam_tutup'];
                                    } else {
                                        $jam_buka = 'Data tidak ditemukan';
                                        $jam_tutup = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $jam_buka; ?></span> - <span><?php echo $jam_tutup; ?></span> WIB
                                </small>
                            <!-- Jam End -->
                            </div> 
                            <br>

                            <!-- Nama Wisata Start -->
                            <?php
                            $query = "SELECT nama_wisata FROM bangkalan WHERE id = 4";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $nama_wisata = $row['nama_wisata'];
                            } else {
                                $nama_wisata = 'Data tidak ditemukan';
                            }
                            ?>
                            <h4><?php echo $nama_wisata; ?></h4>
                            <!-- Nama Wisata End -->

                            <!-- Deskripsi Start -->
                            <?php
                            $query = "SELECT deskripsi FROM bangkalan WHERE id = 4";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $deskripsi = $row['deskripsi'];
                            } else {
                                $deskripsi = 'Data tidak ditemukan';
                            }
                            ?>
                            <p><?php echo $deskripsi; ?><p>
                            <!-- Deskripsi End -->

                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">

                                    <!-- Harga Start -->
                                    <div class="d-flex align-items-center">
                                        <h6 class="m-0 mr-4">
                                            <i class="fa fa-star text-info mr-2"></i>
                                            <?php
                                            $query = "SELECT harga FROM bangkalan WHERE id = 4";
                                            $result = $conn->query($query);

                                            if ($result->num_rows > 0) {
                                                $row = $result->fetch_assoc();
                                                $harga = $row['harga'];
                                            } else {
                                                $harga = 'Data tidak ditemukan';
                                            }
                                            ?>
                                            Rp. <?php echo $harga; ?>
                                        </h6>
                                        <!-- Harga End -->
                                        <a href="pemesanan_bangkalan.php" class="btn btn-info btn-sm py-2 px-4 ml-2">Pesan Sekarang</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Pantai Siring Kemuning End -->

                <!-- Sumber Pocong Start -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                        </ol>

                        <!-- Slides -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                            <img class="d-block w-100" src="sumber pocong.png" alt="Slide 1">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="sumber pocong-2.png" alt="Slide 2">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="sumber pocong-3.png" alt="Slide 3">
                            </div>
                        </div>

                        <!-- Controls -->
                        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                        </div>

                        <div class="p-4">
                            <div style="display: grid; grid-template-rows: auto auto;">
                            <!-- Lokasi Start -->
                                <small class="m-0">
                                    <i class="fa fa-map-marker-alt text-info"></i>
                                    <?php
                                    $query = "SELECT lokasi FROM bangkalan WHERE id = 5";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $lokasi = $row['lokasi'];
                                    } else {
                                        $lokasi = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $lokasi; ?></span>
                                </small>
                            <!-- Lokasi End -->

                                <br>
                            <!-- Jam Start -->
                                <small class="m-0">
                                    <i class="fa fa-calendar-alt text-info"></i>
                                    <?php
                                    $query = "SELECT jam_buka, jam_tutup FROM bangkalan WHERE id = 5";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $jam_buka = $row['jam_buka'];
                                        $jam_tutup = $row['jam_tutup'];
                                    } else {
                                        $jam_buka = 'Data tidak ditemukan';
                                        $jam_tutup = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $jam_buka; ?></span> - <span><?php echo $jam_tutup; ?></span> WIB
                                </small>
                            <!-- Jam End -->
                            </div> 
                            <br>

                            <!-- Nama Wisata Start -->
                            <?php
                            $query = "SELECT nama_wisata FROM bangkalan WHERE id = 5";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $nama_wisata = $row['nama_wisata'];
                            } else {
                                $nama_wisata = 'Data tidak ditemukan';
                            }
                            ?>
                            <h4><?php echo $nama_wisata; ?></h4>
                            <!-- Nama Wisata End -->

                            <!-- Deskripsi Start -->
                            <?php
                            $query = "SELECT deskripsi FROM bangkalan WHERE id = 5";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $deskripsi = $row['deskripsi'];
                            } else {
                                $deskripsi = 'Data tidak ditemukan';
                            }
                            ?>
                            <p><?php echo $deskripsi; ?><p>
                            <!-- Deskripsi End -->

                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">

                                    <!-- Harga Start -->
                                    <div class="d-flex align-items-center">
                                        <h6 class="m-0 mr-4">
                                            <i class="fa fa-star text-info mr-2"></i>
                                            <?php
                                            $query = "SELECT harga FROM bangkalan WHERE id = 5";
                                            $result = $conn->query($query);

                                            if ($result->num_rows > 0) {
                                                $row = $result->fetch_assoc();
                                                $harga = $row['harga'];
                                            } else {
                                                $harga = 'Data tidak ditemukan';
                                            }
                                            ?>
                                            Rp. <?php echo $harga; ?>
                                        </h6>
                                        <!-- Harga End -->
                                       <a href="pemesanan_bangkalan.php" class="btn btn-info btn-sm py-2 px-4 ml-2">Pesan Sekarang</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Sumber Pocong Kemuning End -->

                <!-- Labuhan Mangrove Start -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                        </ol>

                        <!-- Slides -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                            <img class="d-block w-100" src="labuhan mangrove.png" alt="Slide 1">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="labuhan mangrove-2.png" alt="Slide 2">
                            </div>
                            <div class="carousel-item">
                            <img class="d-block w-100" src="labuhan mangrove-3.png" alt="Slide 3">
                            </div>
                        </div>

                        <!-- Controls -->
                        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                        </div>

                        <div class="p-4">
                            <div style="display: grid; grid-template-rows: auto auto;">
                            <!-- Lokasi Start -->
                                <small class="m-0">
                                    <i class="fa fa-map-marker-alt text-info"></i>
                                    <?php
                                    $query = "SELECT lokasi FROM bangkalan WHERE id = 6";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $lokasi = $row['lokasi'];
                                    } else {
                                        $lokasi = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $lokasi; ?></span>
                                </small>
                            <!-- Lokasi End -->

                                <br>
                            <!-- Jam Start -->
                                <small class="m-0">
                                    <i class="fa fa-calendar-alt text-info"></i>
                                    <?php
                                    $query = "SELECT jam_buka, jam_tutup FROM bangkalan WHERE id = 6";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $jam_buka = $row['jam_buka'];
                                        $jam_tutup = $row['jam_tutup'];
                                    } else {
                                        $jam_buka = 'Data tidak ditemukan';
                                        $jam_tutup = 'Data tidak ditemukan';
                                    }
                                    ?>
                                    <span><?php echo $jam_buka; ?></span> - <span><?php echo $jam_tutup; ?></span> WIB
                                </small>
                            <!-- Jam End -->
                            </div> 
                            <br>

                            <!-- Nama Wisata Start -->
                            <?php
                            $query = "SELECT nama_wisata FROM bangkalan WHERE id = 6";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $nama_wisata = $row['nama_wisata'];
                            } else {
                                $nama_wisata = 'Data tidak ditemukan';
                            }
                            ?>
                            <h4><?php echo $nama_wisata; ?></h4>
                            <!-- Nama Wisata End -->

                            <!-- Deskripsi Start -->
                            <?php
                            $query = "SELECT deskripsi FROM bangkalan WHERE id = 6";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $deskripsi = $row['deskripsi'];
                            } else {
                                $deskripsi = 'Data tidak ditemukan';
                            }
                            ?>
                            <p><?php echo $deskripsi; ?><p>
                            <!-- Deskripsi End -->

                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">

                                    <!-- Harga Start -->
                                    <div class="d-flex align-items-center">
                                        <h6 class="m-0 mr-4">
                                            <i class="fa fa-star text-info mr-2"></i>
                                            <?php
                                            $query = "SELECT harga FROM bangkalan WHERE id = 6";
                                            $result = $conn->query($query);

                                            if ($result->num_rows > 0) {
                                                $row = $result->fetch_assoc();
                                                $harga = $row['harga'];
                                            } else {
                                                $harga = 'Data tidak ditemukan';
                                            }
                                            ?>
                                            Rp. <?php echo $harga; ?>
                                        </h6>
                                        <!-- Harga End -->
                                        <a href="pemesanan_bangkalan.php" class="btn btn-info btn-sm py-2 px-4 ml-2">Pesan Sekarang</a>
                                        </div>          

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Labuhan Mangrove End -->
            </div>
        </div>
    </div>
    <!-- Packages End -->

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 py-5 px-sm-3 px-lg-5" style="margin-top: 90px;">
        <div class="row pt-5">
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="text-white text-uppercase mb-4" style="letter-spacing: 5px;">Contact Us</h5>
                <p><i class="fa fa-phone-alt mr-2"></i>089515681396</p>
                <p><i class="fa fa-envelope mr-2"></i>21082010033.com</p>
                
                        </div>
                    </div>
                </div>
         <!-- Logout Modal-->
    <button class="btn btn-info" onclick="logout()">Logout</button>

<script>
    function logout() {
        // Logika logout di sini
        // Anda dapat menambahkan kode untuk menjalankan tindakan logout yang diinginkan
        // Misalnya, menghapus sesi, mengirim permintaan ke server untuk logout, dll.

        // Mengarahkan pengguna ke halaman login
        window.location.href = "index.php";
    }
</script>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-info btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
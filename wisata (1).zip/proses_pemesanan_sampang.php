<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'webwisata';

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die('Koneksi ke database gagal: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $telepon = $_POST['telepon'];
    $destinasi = $_POST['destinasi'];
    $harga = $_POST['harga'];
    $tanggal = $_POST['tanggal'];
    $pembayaran = $_POST['pembayaran'];
    $buktipembayaran = $_POST['buktipembayaran'];


    $sql = "INSERT INTO pemesanan_sampang (nama, email, telepon, destinasi, harga, tanggal, pembayaran, buktipembayaran) VALUES ('$nama', '$email', '$telepon', '$destinasi', '$harga', '$tanggal', '$pembayaran', '$buktipembayaran')";
    if ($conn->query($sql) === TRUE) {
        header("Location: cetak_sampang.php");
        exit(); // Keluar dari skrip PHP setelah mengarahkan pengguna
    } else {
        echo "Terjadi kesalahan: " . $conn->error;
    }
}
?>

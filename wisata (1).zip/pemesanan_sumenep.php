<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'webwisata';

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die('Koneksi ke database gagal: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $telepon = $_POST['telepon'];
    $destinasi = $_POST['destinasi'];
    $harga = $_POST['harga'];
    $tanggal = $_POST['tanggal'];
    $pembayaran = $_POST['pembayaran'];

    
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Form Pemesanan</title>
    
    <!-- Favicon -->
    <link href="logo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Montserrat:500,700&display=swap&subset=latin-ext" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600&display=swap&subset=latin-ext" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

    <style>
        .navbar {
            margin-bottom: 30px; 
        }

        .container {
            border: 3px solid #d1e8f0;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            background-color: #f1f8ff;
            color: #333;
            margin-top: 100px; 
            margin-bottom: 50px;
        }

        .capitalize-first {
            text-transform: capitalize;
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-md navbar-dark bg-dark navbar-custom fixed-top">

        <!-- Image Logo -->
        <a class="navbar-brand logo-image" href="beranda.php">
            <img src="logo.png" alt="logo" width="30%">
        </a>
        
        <!-- Mobile Menu Toggle Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-awesome fas fa-bars"></span>
            <span class="navbar-toggler-awesome fas fa-times"></span>
        </button>
        <!-- end of mobile menu toggle button -->

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="beranda.php">HOME <span class="sr-only">(current)</span></a>
                </li>
            
                <!-- Dropdown Menu -->          
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">DESTINASI</a>
                    <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="bangkalan.php" class="dropdown-item">Bangkalan</a>
                                <a href="sampang.php" class="dropdown-item">Sampang</a>
                                <a href="pamekasan.php" class="dropdown-item">Pamekasan</a>
                                <a href="sumenep.php" class="dropdown-item">Sumenep</a>
                    </div>
                </li>
                <!-- end of dropdown menu -->

                 <!-- Dropdown Menu -->          
                 <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">BOOKING</a>
                    <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="pemesanan_bangkalan.php" class="dropdown-item">Bangkalan</a>
                                <a href="pemesanan_sampang.php" class="dropdown-item">Sampang</a>
                                <a href="pemesanan_pamekasan.php" class="dropdown-item">Pamekasan</a>
                                <a href="pemesanan_sumenep.php" class="dropdown-item">Sumenep</a>
                    </div>
                </li>
                <!-- end of dropdown menu -->

                 <!-- Dropdown Menu -->          
                 <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">AKUN</a>
                    <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="registrasi.php" class="dropdown-item">REGISTRASI</a>
                                <a href="index.php" class="dropdown-item">LOGIN</a>
                                <a href="login_admin.php" class="dropdown-item">ADMIN</a>
                    </div>
                </li>
                <!-- end of dropdown menu -->
         </nav> 
    <!-- end of navbar -->


        <div class="container-fluid py-5">
            <div class="container pt-5 pb-3">
                <h6 class="text-info text-uppercase text-center" style="letter-spacing: 5px;">Sumenep</h6>
                <br>
                <h1 class="text-center">Pemesanan Tiket</h1>
                <br>
                <form method="post" action="proses_pemesanan_Sumenep.php">
                    <div class="form-group">
                        <h6><label for="nama">Nama :</label></h6>
                        <input type="text" class="form-control" id="nama" name="nama" value="Nama" required>
                    </div>
                    <div class="form-group">
                        <h6><label for="email">Email :</label></h6>
                        <input type="email" class="form-control" id="email" name="email" value="Email" required>
                    </div>
                    <div class="form-group">
                        <h6><label for="telepon">Telepon :</label></h6>
                        <input type="text" class="form-control" id="telepon" name="telepon" value="Nomer Telepon" required>
                    </div>
                    <div class="form-group">
                        <h6><label for="destinasi">Destinasi :</label></h6>
                        <select class="form-control" id="destinasi" name="destinasi" onchange="updateHarga()">
                            <option value="">Pilih Destinasi</option>
                            <?php
                            $query = "SELECT * FROM Sumenep";
                            $result = $conn->query($query);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $id = $row['id'];
                                    $nama_wisata = $row['nama_wisata'];

                                    echo "<option value='$id'>$nama_wisata</option>";
                                }
                            } else {
                                echo "<option>Data tidak ditemukan</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <h6><label for="harga">Harga :</label></h6>
                        <input type="text" class="form-control" id="harga" name="harga" value="Harga Tiket" readonly>
                    </div>

                    <script>
                    function updateHarga() {
                        var destinasi = document.getElementById("destinasi");
                        var harga = document.getElementById("harga");

                        var selectedDestinasi = destinasi.options[destinasi.selectedIndex].value;

                        // Buat objek AJAX
                        var xmlhttp = new XMLHttpRequest();

                        // Tentukan permintaan AJAX
                        xmlhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                harga.value = this.responseText;
                            }
                        };

                        // Kirim permintaan AJAX ke file get_harga.php dengan parameter destinasi yang dipilih
                        xmlhttp.open("GET", "get_harga_Sumenep.php?destinasi=" + selectedDestinasi, true);
                        xmlhttp.send();
                    }
                    </script>

                    <div class="form-group">
                        <h6><label for="tanggal">Tanggal :</label></h6>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                    </div>
                    <div class="form-group">
                        <h6><label for="pembayaran">Pembayaran</label></h6>
                        <select class="form-control" id="pembayaran" name="pembayaran">
                            <option value="Tunai">Tunai</option>
                            <option value="Shopeepay">Shopeepay (08574949267)</option>
                            <option value="DANA">DANA (089515681396)</option>
                            <option value="OVO">OVO (089515681396)</option>
                            <option value="BNI">BNI (009876245)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <h6><label for="buktipembayaran">Bukti Pembayaran :</label></h6>
                        <input type="url" class="form-control" id="buktipembayaran" name="buktipembayaran" value="https://drive.google.com/" required>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="btn btn-info">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 py-5 px-sm-3 px-lg-5" style="margin-top: 90px;">
        <div class="row pt-5">
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="text-white text-uppercase mb-4" style="letter-spacing: 5px;">Contact Us</h5>
                <p><i class="fa fa-phone-alt mr-2"></i>089515681396</p>
                <p><i class="fa fa-envelope mr-2"></i>21082010033.com</p>
                
                        </div>
                    </div>
                </div>

                   <!-- Logout Modal-->
    <button class="btn btn-info" onclick="logout()">Logout</button>

<script>
    function logout() {
        // Logika logout di sini
        // Anda dapat menambahkan kode untuk menjalankan tindakan logout yang diinginkan
        // Misalnya, menghapus sesi, mengirim permintaan ke server untuk logout, dll.

        // Mengarahkan pengguna ke halaman login
        window.location.href = "index.php";
    }
</script>

        
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-info btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

</body>

</html>
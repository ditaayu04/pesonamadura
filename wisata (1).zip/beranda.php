<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pesona Madura</title>
    
    <!-- Favicon -->
    <link href="logo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Montserrat:500,700&display=swap&subset=latin-ext" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600&display=swap&subset=latin-ext" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-md navbar-dark navbar-custom fixed-top">

        <!-- Image Logo -->
        <a class="navbar-brand logo-image" href="beranda.php">
            <img src="logo.png" alt="logo" width="30%">
        </a>
        
        <!-- Mobile Menu Toggle Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-awesome fas fa-bars"></span>
            <span class="navbar-toggler-awesome fas fa-times"></span>
        </button>
        <!-- end of mobile menu toggle button -->

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="beranda.php">HOME <span class="sr-only">(current)</span></a>
                </li>
            
                <!-- Dropdown Menu -->          
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">DESTINASI</a>
                    <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="bangkalan.php" class="dropdown-item">Bangkalan</a>
                                <a href="sampang.php" class="dropdown-item">Sampang</a>
                                <a href="pamekasan.php" class="dropdown-item">Pamekasan</a>
                                <a href="sumenep.php" class="dropdown-item">Sumenep</a>
                    </div>
                </li>
                <!-- end of dropdown menu -->

                 <!-- Dropdown Menu -->          
                 <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">BOOKING</a>
                    <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="pemesanan_bangkalan.php" class="dropdown-item">Bangkalan</a>
                                <a href="pemesanan_sampang.php" class="dropdown-item">Sampang</a>
                                <a href="pemesanan_pamekasan.php" class="dropdown-item">Pamekasan</a>
                                <a href="pemesanan_sumenep.php" class="dropdown-item">Sumenep</a>
                    </div>
                </li>
                <!-- end of dropdown menu -->

                 <!-- Dropdown Menu -->          
                 <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">AKUN</a>
                    <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="registrasi.php" class="dropdown-item">REGISTRASI</a>
                                <a href="index.php" class="dropdown-item">LOGIN</a>
                                <a href="login_admin.php" class="dropdown-item">ADMIN</a>
                    </div>
                </li>
                <!-- end of dropdown menu -->
         </nav> 
    <!-- end of navbar -->


    <!-- Carousel Start -->
    <div class="container-fluid p-0">
        <div id="header-carousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="bukit jaddih.png" alt="bukit jaddih">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h4 class="text-white text-uppercase mb-md-3">Mengenal Pesona Madura!</h4>
                            <h1 class="display-3 text-white mb-md-4">Bangkalan</h1>
                            <a href="bangkalan.php" class="btn btn-info py-md-3 px-md-5 mt-2">Lihat Destinasi</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="sumenep.png" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h4 class="text-white text-uppercase mb-md-3">Mengenal Pesona Madura!</h4>
                            <h1 class="display-3 text-white mb-md-4">Sumenep</h1>
                            <a href="sumenep.php" class="btn btn-info py-md-3 px-md-5 mt-2">Lihat Destinasi</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="pamekasan.png" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h4 class="text-white text-uppercase mb-md-3">Mengenal Pesona Madura!</h4>
                            <h1 class="display-3 text-white mb-md-4">Pamekasan</h1>
                            <a href="pamekasan.php" class="btn btn-info py-md-3 px-md-5 mt-2">Lihat Destinasi</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="air terjun toroan.png" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h4 class="text-white text-uppercase mb-md-3">Mengenal Pesona Madura!</h4>
                            <h1 class="display-3 text-white mb-md-4">Sampang</h1>
                            <a href="sampang.php" class="btn btn-info py-md-3 px-md-5 mt-2">Lihat Destinasi</a>
                        </div>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-prev-icon mb-n2"></span>
                </div>
            </a>
            <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-next-icon mb-n2"></span>
                </div>
            </a>
        </div>
    </div>
    <!-- Carousel End -->

    <!-- Feature Start -->
    <br>
    <br>
    <br>
    <div class="container-fluid pb-5">
        <div class="container pb-5">
            <div class="row">
                <div class="col-md-4">
                    <div class="d-flex mb-4 mb-lg-0">
                        <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-info mr-3" style="height: 100px; width: 100px;">
                            <i class="fa fa-2x fa-money-check-alt text-white"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <h5 class="">Tiket Terjangkau</h5>
                            <p class="m-0">Harga tiket yang terjangkau, memberikan akses bagi semua kalangan.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex mb-4 mb-lg-0">
                        <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-info mr-3" style="height: 100px; width: 100px;">
                            <i class="fa fa-2x fa-award text-white"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <h5 class="">Wisata Terbaik</h5>
                            <p class="m-0">Wisata terbaik dengan pengalaman tak terlupakan.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex mb-4 mb-lg-0">
                        <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-info mr-3" style="height: 100px; width: 100px;">
                            <i class="fa fa-2x fa-globe text-white"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <h5 class="">Wisata Kelas Dunia</h5>
                            <p class="m-0">Tidak perlu berkeliling dunia, Madura pun memiliki berbagai destinasi yang sangat indah mempesona.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Feature End -->


    <!-- Destination Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <div class="text-center mb-3 pb-3">
                <h6 class="text-info text-uppercase" style="letter-spacing: 5px;">Destinasi</h6>
                <h1>Eksplor Destinasi Wisata dari Berbagai Kota di Madura</h1>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="bangkalan.jpg" alt="">
                        <a class="destination-overlay text-white text-decoration-none" href="bangkalan.php">
                            <h5 class="text-white">Bangkalan</h5>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="sumenep.jpg" alt="">
                        <a class="destination-overlay text-white text-decoration-none" href="sumenep.php">
                            <h5 class="text-white">Sumenep</h5>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="pamekasan.jpg" alt="">
                        <a class="destination-overlay text-white text-decoration-none" href="pamekasan.php">
                            <h5 class="text-white">Pamekasan</h5>
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="sampang.jpg" alt="">
                        <a class="destination-overlay text-white text-decoration-none" href="sampang.php">
                            <h5 class="text-white">Sampang</h5>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Destination Start -->


    <!-- Team Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Guides</h6>
                <h1>Pemandu Wisata</h1>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-4 col-sm-6 pb-2">
                    <div class="team-item bg-white mb-4">
                        <div class="team-img position-relative overflow-hidden">
                            <img class="img-fluid w-100" src="guide-1.jpg" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-primary btn-square" href="instagram.com/switdita_/"><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-outline-primary btn-square" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                        <div class="text-center py-4">
                            <h5 class="text-truncate">Dita Ayu</h5>
                            <p class="m-0">Bangkalan</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 pb-2">
                    <div class="team-item bg-white mb-4">
                        <div class="team-img position-relative overflow-hidden">
                            <img class="img-fluid w-100" src="guide-11.jpg" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-primary btn-square" href="instagram/switdita_"><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-outline-primary btn-square" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                        <div class="text-center py-4">
                            <h5 class="text-truncate">Dita Ayu</h5>
                            <p class="m-0">Sampang</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 pb-2">
                    <div class="team-item bg-white mb-4">
                        <div class="team-img position-relative overflow-hidden">
                            <img class="img-fluid w-100" src="guide-11.jpg" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-primary btn-square" href=""><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-outline-primary btn-square" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                        <div class="text-center py-4">
                            <h5 class="text-truncate">Dita Ayu</h5>
                            <p class="m-0">Pamekasan</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 pb-2">
                    <div class="team-item bg-white mb-4">
                        <div class="team-img position-relative overflow-hidden">
                            <img class="img-fluid w-100" src="guide-11.jpg" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-primary btn-square" href=""><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-outline-primary btn-square" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                        <div class="text-center py-4">
                            <h5 class="text-truncate">Dita Ayu</h5>
                            <p class="m-0">Sumenep</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Team End -->
    

    <!-- Footer Start -->
   <!-- Footer Start -->
   <div class="container-fluid bg-dark text-white-50 py-5 px-sm-3 px-lg-5" style="margin-top: 90px;">
        <div class="row pt-5">
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="text-white text-uppercase mb-4" style="letter-spacing: 5px;">Contact Us</h5>
                <p><i class="fa fa-phone-alt mr-2"></i>089515681396</p>
                <p><i class="fa fa-envelope mr-2"></i>21082010033.com</p>
                
                        </div>
                    </div>
                </div>
        
                  <!-- Logout Modal-->
    <button class="btn btn-info" onclick="logout()">Logout</button>

<script>
    function logout() {
        // Logika logout di sini
        // Anda dapat menambahkan kode untuk menjalankan tindakan logout yang diinginkan
        // Misalnya, menghapus sesi, mengirim permintaan ke server untuk logout, dll.

        // Mengarahkan pengguna ke halaman login
        window.location.href = "index.php";
    }
</script>
    <!-- Footer End -->

    


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-info btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
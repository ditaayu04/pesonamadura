<?php
$id = $_POST['id'];
$lokasi = $_POST['lokasi'];
$jam_buka = $_POST['jam_buka'];
$jam_tutup = $_POST['jam_tutup'];
$nama_wisata = $_POST['nama_wisata'];
$deskripsi = $_POST['deskripsi'];
$harga = $_POST['harga'];

// Buat koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "webwisata");

if (!$conn) {
    echo "Gagal terhubung ke MySQL: " . mysqli_connect_error();
    exit;
}

$sql = "INSERT INTO sumenep (id, lokasi, jam_buka, jam_tutup, nama_wisata, deskripsi, harga) VALUES ('$id', '$lokasi', '$jam_buka', '$jam_tutup', '$nama_wisata', '$deskripsi', '$harga')";
$query = mysqli_query($conn, $sql);

if ($query) {
    echo "Data wisata berhasil ditambahkan";
} else {
    echo "Gagal menambahkan data wisata: " . mysqli_error($conn);
}

mysqli_close($conn);
?>

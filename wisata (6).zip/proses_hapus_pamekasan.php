<?php
$id = $_POST['id'];

// Buat koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "webwisata");

if (!$conn) {
    echo "Gagal terhubung ke MySQL: " . mysqli_connect_error();
    exit;
}

$sql = "DELETE FROM pamekasan WHERE id = $id";
$query = mysqli_query($conn, $sql);

if ($query) {
    echo "Data wisata berhasil dihapus";
} else {
    echo "Gagal menghapus data wisata: " . mysqli_error($conn);
}

mysqli_close($conn);
?>

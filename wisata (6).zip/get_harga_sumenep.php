<?php
// Ambil nilai destinasi yang dikirim melalui AJAX
$selectedDestinasi = $_GET['destinasi'];

// Buat koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "webwisata");

// Query untuk mendapatkan harga berdasarkan destinasi yang dipilih
$query = "SELECT harga FROM sumenep WHERE id = '$selectedDestinasi'";
$result = mysqli_query($conn, $query);

// Periksa apakah query berhasil
if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $harga = $row['harga'];
    echo $harga;
} else {
    echo "Data tidak ditemukan";
}

// Tutup koneksi database
mysqli_close($conn);
?>
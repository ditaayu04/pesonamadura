<?php
$id = $_POST['id'];
$lokasi = $_POST['lokasi'];
$jam_buka = $_POST['jam_buka'];
$jam_tutup = $_POST['jam_tutup'];
$nama_wisata = $_POST['nama_wisata'];
$deskripsi = $_POST['deskripsi'];
$harga = $_POST['harga'];

// Buat koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "webwisata");

if (!$conn) {
    echo "Gagal terhubung ke MySQL: " . mysqli_connect_error();
    exit;
}

$sql = "UPDATE bangkalan SET lokasi = '$lokasi', jam_buka = '$jam_buka', jam_tutup = '$jam_tutup', nama_wisata = '$nama_wisata',  deskripsi = '$deskripsi', harga = '$harga' WHERE id = $id";
$query = mysqli_query($conn, $sql);

if ($query) {
    echo "Data wisata berhasil diperbarui";
} else {
    echo "Gagal memperbarui data wisata: " . mysqli_error($conn);
}

mysqli_close($conn);
?>

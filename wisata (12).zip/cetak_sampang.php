<?php
require_once("dompdf/autoload.inc.php");
use Dompdf\Dompdf;

// Buat koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "webwisata");

// Periksa koneksi ke database
if (!$conn) {
    die("Gagal terhubung ke database: " . mysqli_connect_error());
}

// Query untuk mendapatkan data terakhir dari database
$query = "SELECT * FROM pemesanan_sampang ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    // Membuat objek Dompdf
    $dompdf = new Dompdf();

    // Membuat header HTML
    $html = '<h1>Detail Pemesanan Tiket Terakhir</h1>';

    // Membuat tabel
    $html .= '<table border="1" cellpadding="5" cellspacing="0">';
    $html .= '<tr><th>Nama</th><th>Email</th><th>Telepon</th><th>Destinasi</th><th>Harga</th><th>Tanggal</th><th>Pembayaran</th></tr>';

    // Menampilkan data terakhir dalam tabel
    $row = mysqli_fetch_assoc($result);
    $html .= '<tr>';
    $html .= '<td>' . $row['nama'] . '</td>';
    $html .= '<td>' . $row['email'] . '</td>';
    $html .= '<td>' . $row['telepon'] . '</td>';
    $html .= '<td>' . $row['destinasi'] . '</td>';
    $html .= '<td>' . $row['harga'] . '</td>';
    $html .= '<td>' . $row['tanggal'] . '</td>';
    $html .= '<td>' . $row['pembayaran'] . '</td>';
    $html .= '</tr>';

    $html .= '</table>';

    $dompdf->loadHtml($html);

    // Mengatur ukuran dan orientasi kertas
    $dompdf->setPaper('A4', 'portrait');

    // Merender konten ke PDF
    $dompdf->render();

    // Mengirimkan file PDF ke browser untuk diunduh
    $dompdf->stream('detail_pemesanan_terakhir.pdf', ['Attachment' => 0]);
} else {
    echo "Tidak ada data yang tersedia.";
}

// Tutup koneksi ke database
mysqli_close($conn);
?>
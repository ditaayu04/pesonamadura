<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "webwisata";
$koneksi = mysqli_connect($host, $user, $password, $database);
?>